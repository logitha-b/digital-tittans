# My First Project > 2025-02-20 7:29pm
https://universe.roboflow.com/logitha/my-first-project-zeort

Provided by a Roboflow user
License: CC BY 4.0

