# demo > 2025-02-20 8:22pm
https://universe.roboflow.com/logitha/demo-l9amo

Provided by a Roboflow user
License: CC BY 4.0

